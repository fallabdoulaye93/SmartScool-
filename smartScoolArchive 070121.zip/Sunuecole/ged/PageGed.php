<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>sunuEcole : Gestion Administrative des Etablissements Scolaires</title>

<link href="../styles/styles.css" rel="stylesheet" type="text/css" />

</head>

<body>
<table width="100%" border="0" cellspacing="4">
  <tr>
    <td height="126" align="left" valign="top"><?php include('../mod_entete.php'); ?></td>
  </tr>
  <tr>
    <td height="614" align="left" valign="top"><table width="100%" border="0" cellspacing="8">
      <tr>
        <td width="200" height="632" align="left" valign="top"><div id="contenu_menu" style="text-align:center"><?php include('../menu_gauche/menu_parmetres.php'); ?></div></td>
        <td width="1365" align="left" valign="top">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="right" valign="middle"><?php include('../footer.php'); ?></td>
  </tr>
</table>
</body>
</html>