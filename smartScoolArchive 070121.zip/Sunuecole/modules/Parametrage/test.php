<?php
/**
 * Created by PhpStorm.
 * User: dev-numherit
 * Date: 14/11/2019
 * Time: 09:52
 */

/*$page = 'test';
header("Content-type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=test.xls");
if(file_exists($page . '.php')){
    ob_start();
    include( $page . '.php');
    $content = ob_get_clean();
}else $content = $page;
echo "\xEF\xBB\xBF"; // UTF-8 BOM
print $content;
exit;*/

echo 's:ssss,sksksksk';

?>