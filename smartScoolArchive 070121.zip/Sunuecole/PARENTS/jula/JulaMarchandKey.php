<?php
	// Votre Clef secr�te (N=num�rique, A=alphanum�rique)
	//$JULA_MERCHANT_KEY = "8d2f3956377942549fd9cea13d08968f5616e698"; // (A32)
	$JULA_MERCHANT_KEY = "6bdcaf4bb572c48f62e93d462a62c06978c5df92"; // (A32)
?>